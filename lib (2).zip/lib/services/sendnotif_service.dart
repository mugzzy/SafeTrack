import 'package:capstone_1/models/sendnotif_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'cache_service.dart'; // Import your CacheService

class MethodsSendNotif {
  final SendNotifModel model;
  final CacheService cacheService = CacheService(); // Instantiate CacheService

  MethodsSendNotif({required this.model});

  // Method to fetch the logged-in user's email and studentID
  void getLoggedInUserEmail() async {
    final User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      model.loggedInUserEmail = user.email;

      try {
        DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid) // Use UID for the document ID
            .get();

        if (userSnapshot.exists) {
          var userData = userSnapshot.data() as Map<String, dynamic>;
          model.loggedInUserStudentId = userData['studentID'];
          await fetchLocationDataAndSetTemplate(); // Fetch location data
        } else {
          // ignore: use_build_context_synchronously
          ScaffoldMessenger.of(model.context).showSnackBar(
            const SnackBar(content: Text('User data not found in Firestore')),
          );
        }
      } catch (e) {
        // Handle errors
        ScaffoldMessenger.of(model.context).showSnackBar(
          SnackBar(content: Text('Error fetching user data: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(model.context).showSnackBar(
        const SnackBar(content: Text('User not logged in')),
      );
    }
  }

  // Method to fetch the location data from Firestore
  Future<void> fetchLocationDataAndSetTemplate() async {
    final User? user =
        FirebaseAuth.instance.currentUser; // Get the current user
    if (user != null) {
      model.isLoading = true;
      try {
        // Fetch user details
        DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        if (!userSnapshot.exists) {
          model.isLoading = false;
          ScaffoldMessenger.of(model.context).showSnackBar(
            const SnackBar(content: Text('User data not found in Firestore')),
          );
          return;
        }

        var userData = userSnapshot.data() as Map<String, dynamic>;
        String username = userData['username'] ?? 'Unknown';

        // Fetch location details
        DocumentSnapshot locationSnapshot = await FirebaseFirestore.instance
            .collection('locations')
            .doc(user.uid) // Use UID for the document ID
            .get();

        if (locationSnapshot.exists) {
          var locationData = locationSnapshot.data() as Map<String, dynamic>;

          // Handle potential null values
          double? latitude = locationData['latitude'];
          double? longitude = locationData['longitude'];
          Timestamp? timestamp = locationData['timestamp'];

          if (latitude != null && longitude != null && timestamp != null) {
            // Format the timestamp
            DateTime dateTime = timestamp.toDate();
            String formattedDate = DateFormat('MMMM dd, yyyy').format(dateTime);
            String formattedTime =
                DateFormat('hh:mm a').format(dateTime); // 12-hour format

            String helpMessageTemplate =
                'An emergency notification was sent by $username. '
                'The last location recorded on $formattedDate at $formattedTime is available at the URL below: https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';

            model.setState(() {
              model.isLoading = false;
              model.controller.text = helpMessageTemplate;
            });
          } else {
            model.isLoading = false;
            ScaffoldMessenger.of(model.context).showSnackBar(
              const SnackBar(content: Text('Incomplete location data')),
            );
          }
        } else {
          // ignore: use_build_context_synchronously
          ScaffoldMessenger.of(model.context).showSnackBar(
            const SnackBar(content: Text('No location data found')),
          );
        }
      } catch (e) {
        model.isLoading = false; // Reset loading state
        ScaffoldMessenger.of(model.context).showSnackBar(
          SnackBar(content: Text('Error fetching location data: $e')),
        );
      }
    } else {
      ScaffoldMessenger.of(model.context).showSnackBar(
        const SnackBar(content: Text('User not logged in')),
      );
    }
  }

  // Method to fetch accepted contacts from Firestore
  Future<List<Map<String, dynamic>>> fetchAcceptedContacts() async {
    if (model.loggedInUserStudentId == null) {
      return [];
    }

    try {
      QuerySnapshot requestsSnapshot = await FirebaseFirestore.instance
          .collection('requests')
          .where('status', isEqualTo: 'Accepted')
          .where('studentID', isEqualTo: model.loggedInUserStudentId)
          .get();

      List<Map<String, dynamic>> contacts = [];
      for (var doc in requestsSnapshot.docs) {
        var requestData = doc.data() as Map<String, dynamic>;

        DocumentSnapshot userSnapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(requestData['parentId'])
            .get();
      }
      return contacts;
    } catch (e) {
      // Handle errors
      ScaffoldMessenger.of(model.context).showSnackBar(
        SnackBar(content: Text('Error fetching contacts: $e')),
      );
      return [];
    }
  }

  // Method to select/unselect a contact from the list
  Future<void> selectContact(Map<String, dynamic> contact) async {
    model.setState(() {
      if (model.selectedContacts.contains(contact)) {
        model.selectedContacts.remove(contact);
      } else if (model.selectedContacts.length < model.maxContacts) {
        model.selectedContacts.add(contact);
      } else {
        ScaffoldMessenger.of(model.context).showSnackBar(
          SnackBar(
              content: Text(
                  'You can only select up to ${model.maxContacts} contacts')),
        );
      }
    });

    // Save selected contacts to cache
    await cacheService.saveSelectedParents(model.selectedContacts);
  }

  // Method to load cached parents
  Future<void> loadCachedParents() async {
    List<Map<String, dynamic>> cachedParents =
        await cacheService.loadSelectedParents();
    model.selectedContacts.addAll(cachedParents);
    model.setState(() {}); // Refresh the UI with cached data
  }

// Method to handle sending emergency notification
  void sendEmergencyNotification() async {
    if (model.controller.text.trim().isEmpty ||
        model.selectedContacts.isEmpty) {
      model.setState(() {
        model.hasError = true;
      });
      ScaffoldMessenger.of(model.context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a message and select contacts'),
        ),
      );
      return;
    }

    try {
      // Get the currently logged-in user
      final User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        ScaffoldMessenger.of(model.context).showSnackBar(
          const SnackBar(content: Text('User not logged in')),
        );
        return;
      }

// Extract `parentId` and add default `status` for each contact
      final List<Map<String, dynamic>> recipients =
          model.selectedContacts.map((contact) {
        return {
          'parentId': contact['parentId'] as String,
          'status': 'unseen', // Default status for every contact
        };
      }).toList();

      // Notification data
      Map<String, dynamic> notificationData = {
        'studentId': model.loggedInUserStudentId,
        'userEmail': model.loggedInUserEmail,
        'userId': user.uid,
        'message': model.controller.text.trim(),
        'recipients': recipients, // Store only parent names
        'timestamp': FieldValue.serverTimestamp(),
      };

      // Add to Firestore
      await FirebaseFirestore.instance
          .collection('student_notifications')
          .add(notificationData); // Use auto-generated document ID
    } catch (e) {
      ScaffoldMessenger.of(model.context).showSnackBar(
        SnackBar(content: Text('Failed to send notification: $e')),
      );
    }
  }

  // Method to show contact list in a modal
  Future<void> showContactList() async {
    List<Map<String, dynamic>> contacts = await fetchAcceptedContacts();

    showModalBottomSheet(
      // ignore: use_build_context_synchronously
      context: model.context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16.0),
          child: contacts.isNotEmpty
              ? ListView.builder(
                  itemCount: contacts.length,
                  itemBuilder: (context, index) {
                    final contact = contacts[index];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: NetworkImage(contact['profileImage']),
                      ),
                      title: Text(contact['username'] ?? 'Unknown'),
                      subtitle: Text('Email: ${contact['email']}'),
                      trailing: model.selectedContacts.contains(contact)
                          ? const Icon(Icons.check_circle, color: Colors.green)
                          : const Icon(Icons.circle_outlined),
                      onTap: () {
                        selectContact(contact);
                        Navigator.pop(context);
                      },
                    );
                  },
                )
              : const Center(
                  child: Text(
                    'No contacts available',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ),
        );
      },
    );
  }
}
