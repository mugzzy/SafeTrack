import 'package:capstone_1/models/sendnotif_model.dart';
import 'package:capstone_1/services/sendnotif_service.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StudentSendnotif extends StatefulWidget {
  const StudentSendnotif({super.key});

  @override
  _StudentSendnotifState createState() => _StudentSendnotifState();
}

class _StudentSendnotifState extends State<StudentSendnotif> {
  late MethodsSendNotif methodsSendNotif;
  late final SendNotifModel model;
  bool isLoading = true;
  bool hasError = false;
  bool isEditing = false;
  final TextEditingController _controller = TextEditingController();
  List<Map<String, dynamic>> selectedContacts = [];
  int maxContacts = 3;

  @override
  void initState() {
    super.initState();
    _loadSavedMessage();

    model = SendNotifModel(
      context: context,
      setState: (VoidCallback fn) => setState(fn),
      selectedContacts: selectedContacts,
      maxContacts: maxContacts,
      isLoading: isLoading,
      controller: _controller,
      hasError: hasError,
    );

    methodsSendNotif = MethodsSendNotif(model: model);
    methodsSendNotif.getLoggedInUserEmail();
    methodsSendNotif.loadCachedParents();
  }

  Future<void> _loadSavedMessage() async {
    final prefs = await SharedPreferences.getInstance();
    _controller.text = prefs.getString('helpMessage') ?? '';
  }

  Future<void> _saveHelpMessage() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('helpMessage', _controller.text);
  }

  Future<void> _showContactList() async {
    await methodsSendNotif.showContactList();
  }

  void _selectContact(Map<String, dynamic> contact) {
    setState(() {
      methodsSendNotif.selectContact(contact);
      selectedContacts = model.selectedContacts;
    });
  }

  Future<void> _sendEmergencyNotification() async {
    try {
      methodsSendNotif.sendEmergencyNotification();

      // Show success dialog with auto-dismiss
      showDialog(
        context: context,
        builder: (BuildContext context) {
          Future.delayed(const Duration(seconds: 3), () {
            if (Navigator.of(context).canPop()) {
              Navigator.of(context).pop(); // Close the dialog after 3 seconds
            }
          });
          return const AlertDialog(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.check_circle,
                  color: Colors.blueAccent,
                  size: 80, // Bigger icon
                ),
                SizedBox(height: 20),
                Text(
                  'Notification Sent',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10),
                Text(
                  'The emergency notification has been successfully sent.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );
    } catch (e) {
      setState(() {
        hasError = true;
      });

      // Show error dialog with auto-dismiss
      showDialog(
        context: context,
        builder: (BuildContext context) {
          Future.delayed(const Duration(seconds: 3), () {
            if (Navigator.of(context).canPop()) {
              Navigator.of(context).pop(); // Close the dialog after 3 seconds
            }
          });
          return AlertDialog(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.error,
                  color: Colors.red,
                  size: 80, // Bigger icon
                ),
                const SizedBox(height: 20),
                const Text(
                  'Error',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                Text(
                  'Failed to send notification: $e',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset:
          true, // Ensures the UI resizes when the keyboard is shown
      appBar: AppBar(
        title: const Text('Emergency Notification'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'SEND TO:',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: List.generate(maxContacts, (index) {
                        if (index < selectedContacts.length) {
                          var contact = selectedContacts[index];
                          String? profileImage = contact['profileImage'];
                          String username = contact['username'] ?? 'Unknown';
                          ImageProvider profileImageProvider;

                          if (profileImage != null &&
                              profileImage.startsWith('http')) {
                            profileImageProvider = NetworkImage(profileImage);
                          } else {
                            profileImageProvider = const AssetImage(
                                'assets/images/default_profile.png');
                          }

                          return Column(
                            children: [
                              GestureDetector(
                                onTap: () => _selectContact(contact),
                                child: CircleAvatar(
                                  radius: 30,
                                  backgroundImage: profileImageProvider,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                username,
                                style: const TextStyle(fontSize: 14),
                              ),
                            ],
                          );
                        } else {
                          return Column(
                            children: [
                              IconButton(
                                onPressed: _showContactList,
                                icon: const Icon(Icons.add_circle_outline,
                                    size: 50),
                              ),
                              const SizedBox(height: 5),
                              const Text(
                                '',
                                style: TextStyle(fontSize: 14),
                              ),
                            ],
                          );
                        }
                      }),
                    ),
                    const SizedBox(height: 20),
                    const Divider(thickness: 1),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8.0),
                        color: hasError ? Colors.red[100] : Colors.grey[200],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Help Message:',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 10),
                          isEditing
                              ? TextField(
                                  controller: _controller,
                                  maxLines: null,
                                  decoration: InputDecoration(
                                    border: const OutlineInputBorder(),
                                    errorText: hasError &&
                                            _controller.text.trim().isEmpty
                                        ? 'Message cannot be empty'
                                        : null,
                                  ),
                                )
                              : Text(
                                  _controller.text,
                                  style: const TextStyle(fontSize: 14),
                                ),
                        ],
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () async {
                          setState(() {
                            isEditing = !isEditing;
                          });
                          if (!isEditing && _controller.text.isNotEmpty) {
                            await _saveHelpMessage();
                          }
                        },
                        child: Text(
                          isEditing ? 'SAVE' : 'EDIT',
                          style: const TextStyle(
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Bottom button (stays fixed and visible)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity, // Makes the button span the full width
                child: ElevatedButton.icon(
                  onPressed: selectedContacts.isNotEmpty
                      ? _sendEmergencyNotification
                      : null,
                  icon: const Icon(Icons.notification_important),
                  label: const Text('Send Emergency Notification'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    backgroundColor: selectedContacts.isNotEmpty
                        ? Colors.blue[900]
                        : Colors.grey[400], // Disabled button background color
                    foregroundColor: selectedContacts.isNotEmpty
                        ? Colors.white
                        : Colors.black54, // Dynamically change text color
                    textStyle: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
