import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import '../models/event_model.dart';

class EventUpdatesService {
  Map<String, String> _geofenceState = {};

  Future<void> checkStudentLocations(EventModel event,
      Function(int outsideCount, int leftCount) updateCounts) async {
    if (!event.isOngoing) return;

    try {
      final studentsSnapshot = await FirebaseFirestore.instance
          .collection('locations')
          .where(FieldPath.documentId, whereIn: event.studentIds)
          .get();

      int outsideCount = 0;
      int leftCount = 0;
      Map<String, String> updatedStates = {};

      for (var doc in studentsSnapshot.docs) {
        final studentId = doc.id;
        final locationData = doc.data();
        final latitude = locationData['latitude'];
        final longitude = locationData['longitude'];

        double distance = calculateDistance(
          event.geofenceCenter.latitude,
          event.geofenceCenter.longitude,
          latitude,
          longitude,
        );

        final isInside = distance <= event.geofenceRadius;
        String newState = isInside ? "inside" : "outside";

        if (_geofenceState[studentId] != newState) {
          if (_geofenceState[studentId] == "inside" && newState == "outside") {
            leftCount++;
          }
          _geofenceState[studentId] = newState;
          updatedStates[studentId] = newState;
        }

        if (newState == "outside") outsideCount++;
      }

      for (var entry in updatedStates.entries) {
        String studentId = entry.key;

        var matchingDocs =
            studentsSnapshot.docs.where((doc) => doc.id == studentId);

        if (matchingDocs.isNotEmpty) {
          var matchingDoc = matchingDocs.first;
          String? email = matchingDoc.data()['email'];

          if (email != null) {
            await saveUpdate(
              eventId: event.eventId,
              email: email,
              update: updatedStates[studentId] == "outside"
                  ? 'went outside the event.'
                  : 'entered the event.',
            );
          }
        }
      }

      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(event.eventId)
          .collection('event_updates')
          .doc('event_summary')
          .set({
        'outsideCount': outsideCount,
        'leftCount': leftCount,
        'timestamp': Timestamp.now(),
      }, SetOptions(merge: true));

      updateCounts(outsideCount, leftCount);
    } catch (e) {
      print('Error checking student locations: $e');
    }
  }

  Future<void> saveUpdate(
      {required String eventId,
      required String email,
      required String update}) async {
    try {
      var querySnapshot = await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(eventId)
          .collection('event_notifications')
          .where('email', isEqualTo: email)
          .orderBy('timestamp', descending: true)
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        var lastUpdate = querySnapshot.docs.first.data();
        if (lastUpdate['update'] == update) {
          print("Same notification exists. Skipping.");
          return;
        }
      }

      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(eventId)
          .collection('event_notifications')
          .add({
        'email': email,
        'update': update,
        'timestamp': Timestamp.now(),
      });

      print("Update saved for $email: $update");
    } catch (error) {
      print("Error saving update: $error");
    }
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371000; // Earth's radius in meters
    double dLat = (lat2 - lat1) * (pi / 180);
    double dLon = (lon2 - lon1) * (pi / 180);

    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(lat1 * (pi / 180)) *
            cos(lat2 * (pi / 180)) *
            sin(dLon / 2) *
            sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  String formatTimestamp(Timestamp timestamp) {
    return DateFormat('MM/dd/yyyy hh:mm a').format(timestamp.toDate());
  }
}
