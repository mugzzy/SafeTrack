import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../models/event_model.dart';

class EventUpdates extends StatefulWidget {
  final EventModel event;

  EventUpdates({required this.event});

  @override
  _EventUpdatesState createState() => _EventUpdatesState();
}

class _EventUpdatesState extends State<EventUpdates> {
  Map<String, String> _geofenceState =
      {}; // Tracks each student's current state
  Map<String, int> _leaveCount = {}; // Tracks how many times a student left
  Map<String, Timer?> _outsideTimers =
      {}; // Tracks timers for outside durations
  Map<String, Duration> _outsideDurations =
      {}; // Tracks total outside durations
  int _outsideCount = 0; // Tracks count of students currently outside

  @override
  void initState() {
    super.initState();
    checkStudentLocations(); // Start monitoring locations when the widget is built
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Event Updates',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'Students outside: $_outsideCount',
            style: TextStyle(color: Colors.redAccent, fontSize: 16),
          ),
        ],
      ),
      content: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('event_notifications')
            .doc(widget.event.eventId)
            .collection('event_notifications')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No updates available.'));
          }

          final updates = snapshot.data!.docs;

          return Container(
            width: double.maxFinite,
            height: 400,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: updates.length,
              separatorBuilder: (context, index) => Divider(),
              itemBuilder: (context, index) {
                var update = updates[index].data() as Map<String, dynamic>;
                return ListTile(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
                  leading: Icon(
                    Icons.update,
                    color: Colors.blueAccent,
                  ),
                  title: Text(
                    update['email'] ?? 'Summary',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Row(
                    children: [
                      Expanded(
                        child: Text(update['update']),
                      ),
                      Text(
                        formatTimestamp(update['timestamp']),
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            'Close',
            style: TextStyle(color: Colors.blueAccent),
          ),
        ),
      ],
    );
  }

  String formatTimestamp(Timestamp timestamp) {
    final DateTime dateTime = timestamp.toDate();
    final DateFormat formatter = DateFormat('MM/dd/yyyy hh:mm a');
    return formatter.format(dateTime);
  }

  Future<void> checkStudentLocations() async {
    if (!widget.event.isOngoing) return; // Only check during ongoing events

    int outsideCount = 0; // Temporary counter for students outside
    for (var studentId in widget.event.studentIds) {
      final locationSnapshot = await FirebaseFirestore.instance
          .collection('locations')
          .doc(studentId)
          .get();

      if (!locationSnapshot.exists) continue;

      final locationData = locationSnapshot.data()!;
      final latitude = locationData['latitude'];
      final longitude = locationData['longitude'];

      double distance = calculateDistance(
        widget.event.geofenceCenter.latitude,
        widget.event.geofenceCenter.longitude,
        latitude,
        longitude,
      );

      final isInside = distance <= widget.event.geofenceRadius;
      String newState = isInside ? "inside" : "outside";
      String? previousState = _geofenceState[studentId];

      if (previousState == null || previousState != newState) {
        _geofenceState[studentId] = newState;

        if (newState == "inside") {
          stopOutsideTimer(studentId);
        } else if (newState == "outside") {
          incrementLeaveCount(studentId);
          startOutsideTimer(studentId);
        }

        saveUpdate(
          email: locationData['email'],
          update:
              isInside ? 'arrived at the event.' : 'left the event perimeter.',
        );
      }

      // Increment the count if the student is outside
      if (newState == "outside") {
        outsideCount++;
      }
    }

    // Update the outside count in the state and save to Firebase
    setState(() {
      _outsideCount = outsideCount;
    });
    saveOutsideCountAndLeaveCounts();
  }

  Future<void> saveUpdate({
    required String email,
    required String update,
  }) async {
    try {
      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(widget.event.eventId)
          .collection('event_notifications')
          .add({
        'email': email,
        'update': update,
        'timestamp': Timestamp.now(),
      });
      print("Update saved for $email: $update");
    } catch (error) {
      print("Error saving update for $email: $update. Error: $error");
    }
  }

  Future<void> saveOutsideCountAndLeaveCounts() async {
    try {
      // Fixed document ID for the event updates
      String docId = "event_summary";

      // Prepare the map of students and their leave counts
      Map<String, dynamic> studentsLeaveCounts =
          _leaveCount.map((email, leaveCount) => MapEntry(email, leaveCount));

      // Save outside count and students' leave counts in the same document
      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(widget.event.eventId)
          .collection('event_updates')
          .doc(docId) // Reference the specific document
          .set(
        {
          'update': 'Total students outside: $_outsideCount',
          'outsideCount': _outsideCount,
          'studentsLeaveCounts': studentsLeaveCounts,
          'timestamp': Timestamp.now(),
        },
        SetOptions(merge: true), // Merge to avoid overwriting other fields
      );
      print(
          "Event summary saved: $_outsideCount, Students Leave Counts: $studentsLeaveCounts");
    } catch (error) {
      print("Error saving event summary: $error");
    }
  }

  void incrementLeaveCount(String studentId) async {
    try {
      final locationSnapshot = await FirebaseFirestore.instance
          .collection('locations')
          .doc(studentId)
          .get();

      if (locationSnapshot.exists) {
        final email = locationSnapshot.data()?['email'] ?? 'unknown';

        // Increment the leave count for the student by email
        _leaveCount[email] = (_leaveCount[email] ?? 0) + 1;

        // Save updated leave counts
        saveOutsideCountAndLeaveCounts();
      }
    } catch (error) {
      print("Error retrieving email for student ID $studentId: $error");
    }
  }

  void startOutsideTimer(String studentId) {
    if (_outsideTimers[studentId] != null) {
      _outsideTimers[studentId]?.cancel();
    }

    _outsideTimers[studentId] = Timer.periodic(Duration(seconds: 1), (timer) {
      _outsideDurations[studentId] =
          (_outsideDurations[studentId] ?? Duration.zero) +
              Duration(seconds: 1);
    });
  }

  void stopOutsideTimer(String studentId) {
    _outsideTimers[studentId]?.cancel();
    _outsideTimers[studentId] = null;
  }

  Future<void> fetchStudentsOutside() async {
    try {
      final docSnapshot = await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(widget.event.eventId)
          .collection('event_updates')
          .doc('event_summary')
          .get();

      if (docSnapshot.exists && docSnapshot.data() != null) {
        final data = docSnapshot.data()!;
        setState(() {
          _outsideCount = data['outsideCount'] ?? 0;
          if (data['studentsLeaveCounts'] is Map<String, dynamic>) {
            _leaveCount = Map<String, int>.from(data['studentsLeaveCounts']);
          }
        });
      } else {
        setState(() {
          _outsideCount = 0;
          _leaveCount = {};
        });
      }
    } catch (e) {
      print("Error fetching student data: $e");
    }
  }

  void showStudentDetailsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Students Who Left"),
          content: _leaveCount.isNotEmpty
              ? SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: _leaveCount.entries.map((entry) {
                      return ListTile(
                        title: Text("Student: \${entry.key}"),
                        subtitle: Text("Leave Count: \${entry.value}"),
                      );
                    }).toList(),
                  ),
                )
              : const Text("No students have left the event."),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Close"),
            )
          ],
        );
      },
    );
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371e3; // Earth's radius in meters
    final double phi1 = lat1 * pi / 180;
    final double phi2 = lat2 * pi / 180;
    final double deltaPhi = (lat2 - lat1) * pi / 180;
    final double deltaLambda = (lon2 - lon1) * pi / 180;

    final double a = sin(deltaPhi / 2) * sin(deltaPhi / 2) +
        cos(phi1) * cos(phi2) * sin(deltaLambda / 2) * sin(deltaLambda / 2);
    final double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return R * c;
  }
}
