import 'package:cloud_firestore/cloud_firestore.dart';

class EventSummaryService {
  final String eventId;
  int _outsideCount = 0;
  Map<String, int> _leaveCount = {};

  EventSummaryService(this.eventId);

  Future<void> saveOutsideCountAndLeaveCounts() async {
    try {
      String docId = "event_summary";

      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(eventId)
          .collection('event_updates')
          .doc(docId)
          .set(
        {
          'update': 'Total students outside: $_outsideCount',
          'outsideCount': _outsideCount,
          'studentsLeaveCounts': _leaveCount,
          'timestamp': Timestamp.now(),
        },
        SetOptions(merge: true),
      );

      print(
          "Event summary saved: $_outsideCount, Students Leave Counts: $_leaveCount");
    } catch (error) {
      print("Error saving event summary: $error");
    }
  }

  Future<void> incrementLeaveCount(String studentId) async {
    try {
      await FirebaseFirestore.instance.runTransaction((transaction) async {
        final locationRef =
            FirebaseFirestore.instance.collection('locations').doc(studentId);
        final locationSnapshot = await transaction.get(locationRef);

        if (!locationSnapshot.exists) return;

        final email = locationSnapshot.data()?['email'] ?? 'unknown';
        final eventRef = FirebaseFirestore.instance
            .collection('event_notifications')
            .doc(eventId)
            .collection('event_updates')
            .doc('event_summary');

        final eventSnapshot = await transaction.get(eventRef);
        Map<String, dynamic> eventData =
            eventSnapshot.exists ? eventSnapshot.data()! : {};

        Map<String, int> updatedLeaveCounts =
            Map<String, int>.from(eventData['studentsLeaveCounts'] ?? {});
        updatedLeaveCounts[email] = (updatedLeaveCounts[email] ?? 0) + 1;

        transaction.set(
            eventRef,
            {
              'studentsLeaveCounts': updatedLeaveCounts,
              'timestamp': Timestamp.now(),
            },
            SetOptions(merge: true));
      });
    } catch (error) {
      print("Error updating leave count for student ID $studentId: $error");
    }
  }

  void setOutsideCount(int count) {
    _outsideCount = count;
  }

  Future<void> fetchLeaveCounts() async {
    try {
      String docId = "event_summary";
      final docSnapshot = await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(eventId)
          .collection('event_updates')
          .doc(docId)
          .get();

      if (docSnapshot.exists && docSnapshot.data() != null) {
        final data = docSnapshot.data()!;
        _outsideCount = data['outsideCount'] ?? 0;
        if (data['studentsLeaveCounts'] is Map<String, dynamic>) {
          _leaveCount = Map<String, int>.from(data['studentsLeaveCounts']);
        }
      }
    } catch (e) {
      print("Error fetching student leave counts: $e");
    }
  }
}
