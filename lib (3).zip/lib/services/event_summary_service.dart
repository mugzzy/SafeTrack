import 'package:cloud_firestore/cloud_firestore.dart';

class EventSummaryService {
  final String eventId;
  int _outsideCount = 0;
  Map<String, int> _leaveCount = {};

  EventSummaryService(this.eventId);

  Future<void> saveOutsideCountAndLeaveCounts() async {
    try {
      String docId = "event_summary";

      Map<String, dynamic> studentsLeaveCounts =
          _leaveCount.map((email, leaveCount) => MapEntry(email, leaveCount));

      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(eventId)
          .collection('event_updates')
          .doc(docId)
          .set(
        {
          'update': 'Total students outside: $_outsideCount',
          'outsideCount': _outsideCount,
          'studentsLeaveCounts': studentsLeaveCounts,
          'timestamp': Timestamp.now(),
        },
        SetOptions(merge: true),
      );

      print(
          "Event summary saved: $_outsideCount, Students Leave Counts: $studentsLeaveCounts");
    } catch (error) {
      print("Error saving event summary: $error");
    }
  }

  Future<void> incrementLeaveCount(String studentId) async {
    try {
      final locationSnapshot = await FirebaseFirestore.instance
          .collection('locations')
          .doc(studentId)
          .get();

      if (locationSnapshot.exists) {
        final email = locationSnapshot.data()?['email'] ?? 'unknown';

        _leaveCount[email] = (_leaveCount[email] ?? 0) + 1;

        saveOutsideCountAndLeaveCounts();
      }
    } catch (error) {
      print("Error retrieving email for student ID $studentId: $error");
    }
  }

  void setOutsideCount(int count) {
    _outsideCount = count;
  }
}
