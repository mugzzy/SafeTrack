import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../models/event_model.dart';
import '../../../services/event_summary_service.dart';

class EventUpdates extends StatefulWidget {
  final EventModel event;

  EventUpdates({required this.event});

  @override
  _EventUpdatesState createState() => _EventUpdatesState();
}

class _EventUpdatesState extends State<EventUpdates> {
  late EventSummaryService eventService;
  Map<String, String> _geofenceState = {};
  Map<String, int> _leaveCount = {};
  int _outsideCount = 0;

  @override
  void initState() {
    super.initState();
    eventService = EventSummaryService(widget.event.eventId);
    checkStudentLocations();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Event Updates', style: TextStyle(fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Students outside: $_outsideCount',
              style: TextStyle(color: Colors.redAccent, fontSize: 16)),
        ],
      ),
      content: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('event_notifications')
            .doc(widget.event.eventId)
            .collection('event_notifications')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No updates available.'));
          }

          final updates = snapshot.data!.docs;

          return Container(
            width: double.maxFinite,
            height: 400,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: updates.length,
              separatorBuilder: (context, index) => Divider(),
              itemBuilder: (context, index) {
                var update = updates[index].data() as Map<String, dynamic>;
                return ListTile(
                  contentPadding:
                      EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
                  leading: Icon(Icons.update, color: Colors.blueAccent),
                  title: Text(update['email'] ?? 'Summary',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Row(
                    children: [
                      Expanded(child: Text(update['update'])),
                      Text(
                        formatTimestamp(update['timestamp']),
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('Close', style: TextStyle(color: Colors.blueAccent)),
        ),
      ],
    );
  }

  String formatTimestamp(Timestamp timestamp) {
    return DateFormat('MM/dd/yyyy hh:mm a').format(timestamp.toDate());
  }

  Future<void> checkStudentLocations() async {
    if (!widget.event.isOngoing) return;

    try {
      final studentsSnapshot = await FirebaseFirestore.instance
          .collection('locations')
          .where(FieldPath.documentId, whereIn: widget.event.studentIds)
          .get();

      int outsideCount = 0;
      Map<String, String> updatedStates = {};

      for (var doc in studentsSnapshot.docs) {
        final studentId = doc.id;
        final locationData = doc.data();
        final latitude = locationData['latitude'];
        final longitude = locationData['longitude'];

        double distance = calculateDistance(
          widget.event.geofenceCenter.latitude,
          widget.event.geofenceCenter.longitude,
          latitude,
          longitude,
        );

        final isInside = distance <= widget.event.geofenceRadius;
        String newState = isInside ? "inside" : "outside";

        if (_geofenceState[studentId] != newState) {
          _geofenceState[studentId] = newState;
          updatedStates[studentId] = newState;
        }

        if (newState == "outside") outsideCount++;
      }

      // Save updates in batch instead of multiple calls inside the loop
      for (var entry in updatedStates.entries) {
        String studentId = entry.key;
        String newState = entry.value;
        String email = studentsSnapshot.docs
            .firstWhere((doc) => doc.id == studentId)
            .data()['email'];

        saveUpdate(
          email: email,
          update: newState == "outside"
              ? 'outside the event .'
              : 'entered at the event.',
        );

        if (newState == "outside") {
          _leaveCount[studentId] = (_leaveCount[studentId] ?? 0) + 1;
        }
      }

      setState(() {
        _outsideCount = outsideCount;
      });

      eventService.saveOutsideCountAndLeaveCounts();
    } catch (e) {
      print('Error checking student locations: $e');
    }
  }

  Future<void> saveUpdate(
      {required String email, required String update}) async {
    try {
      var querySnapshot = await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(widget.event.eventId)
          .collection('event_notifications')
          .where('email', isEqualTo: email)
          .orderBy('timestamp', descending: true)
          .limit(1) // Fetch only the most recent notification
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        var lastUpdate = querySnapshot.docs.first.data();
        if (lastUpdate['update'] == update) {
          print("Same notification already exists. Skipping update.");
          return; // Exit the function without saving a duplicate update
        }
      }

      await FirebaseFirestore.instance
          .collection('event_notifications')
          .doc(widget.event.eventId)
          .collection('event_notifications')
          .add({
        'email': email,
        'update': update,
        'timestamp': Timestamp.now(),
      });

      print("Update saved for $email: $update");
    } catch (error) {
      print("Error saving update: $error");
    }
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371000; // Earth's radius in meters
    double dLat = (lat2 - lat1) * (3.14159265359 / 180);
    double dLon = (lon2 - lon1) * (3.14159265359 / 180);

    double a = (sin(dLat / 2) * sin(dLat / 2)) +
        cos(lat1 * (3.14159265359 / 180)) *
            cos(lat2 * (3.14159265359 / 180)) *
            (sin(dLon / 2) * sin(dLon / 2));

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c; // Distance in meters
  }
}
